<?php include 'koneksi.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css">
    <title>Register User</title>
</head>

<body>

    <header class="main-header">
        <div class="logo-title">
            <img src="rpl.jpg" alt="logo" class="logo">
            <h1>Register User</h1>
        </div>
        <nav>
            <a href="">Home</a>
        </nav>
    </header>

    <div class="register-wrapper">
        <form action="" class="register-form">
            <h2>Register User</h2>

            <label for="Username">Username</label>
            <input type="text" id="username" name="username" placeholder="Username"required>

            <label for="Password">Password</label>
            <input type="Password" id="password" name="usernme" placeholder="Password"required>

            <label for="foto">Foto</label>
            <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/jpg"required>
            <small>PNG, JPEG, UP to 2MB</small>

        <label for="status">Status</label>
        <select name="status" id="status" required>
            <option value="">-- Pilih --</option>
            <option value="siswa">Siswa</option>
            <option value="guru">Guru</option>
        </select> 
        
        <button type="submit"class="register-btn">Register</button>
        <br><br>
        <a href="login.php">Sudah punya akun</a>
        </form>
    </div>\

<footer>
    <p>@ UKK TAHUN PELAJARAN 2025/2026</p>
</footer>
</body>
</html>
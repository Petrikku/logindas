<?php include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $status   = mysqli_real_escape_string($koneksi, $_POST['status']);

    $query = "SELECT * FROM tbl_user WHERE username='$username' AND password='$password' AND status='$status'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['username'] = $username;
        $_SESSION['status'] = $status;
        header("Location: input.php");
        exit();
    } else {
        echo "<script>alert('Login gagal! Periksa kembali username, password, atau peran.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <main>
        <img src="rpl.jpg" alt="logo">
        <p>Login user</p>
        <h1>Login</h1>

        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>

        <select name="status">
            <option value="">--Pilih--</option>
            <option value="siswa">Siswa</option>
            <option value="Guru">Guru</option>
        </select>

        <button type="submit">Login</button>

        <p>Belum punya akun?</p>
        <a href="register.php">Register</a>
        </form>
    </main>
</body>
</html>
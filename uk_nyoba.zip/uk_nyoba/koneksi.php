<?php 

$hostname = "localhost";
$username = "root";
$password = "";
$db = "ukk1";

$koneksi = new mysqli($hostname, $username, $password, $db);

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
} 

?>